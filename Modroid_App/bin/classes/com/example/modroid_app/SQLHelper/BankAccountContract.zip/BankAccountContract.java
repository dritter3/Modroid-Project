package com.example.modroid_app.SQLHelper;

public class BankAccountContract {


	public static final class BFeedEntry{
		public static final String TABLE_NAME = "BankAccountList";
		//public static final String COLUMN_ = ""
				
	}

}
